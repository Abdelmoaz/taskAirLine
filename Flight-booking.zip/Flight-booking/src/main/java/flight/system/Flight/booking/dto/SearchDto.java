package flight.system.Flight.booking.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.util.Date;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SearchDto {
    @JsonFormat(pattern="dd/MM/yyyy")
    private Date start;

    @JsonFormat(pattern="dd/MM/yyyy")
    private Date end;

}
