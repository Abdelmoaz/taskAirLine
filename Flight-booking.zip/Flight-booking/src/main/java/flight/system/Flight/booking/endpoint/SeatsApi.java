package flight.system.Flight.booking.endpoint;

import flight.system.Flight.booking.dto.SearchDto;
import flight.system.Flight.booking.dto.SeatDto;
import flight.system.Flight.booking.entity.Flight;
import flight.system.Flight.booking.entity.Seat;
import flight.system.Flight.booking.service.FlightService;
import flight.system.Flight.booking.service.SeatBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/seats-booking")
public class SeatsApi {

    @Autowired
    private SeatBookingService seatBookingService;
    @Autowired
    private FlightService flightService;



    @PostMapping("/available")
    public ResponseEntity<?> getAvailableSeats(@RequestBody SearchDto searchDto){
        List<Flight> flights = flightService.getFlights(searchDto.getStart(), searchDto.getEnd());
        return ResponseEntity.ok( seatBookingService.getAvailableSeats(flights,true));
    }

    @PostMapping("/Add-Flight")
    public ResponseEntity<?> saveFlight(@RequestBody Flight flight){

        return ResponseEntity.ok( flightService.saveFlight(flight));


    }

    @PostMapping("/Add-Seat")
    public ResponseEntity<?> saveSeat(@RequestBody Seat seat){

        return ResponseEntity.ok( seatBookingService.saveSeat(seat));


    }

    @PostMapping("/Book-Seat")
    public ResponseEntity<?> bookSeat(@RequestBody SeatDto seatDto){

        return ResponseEntity.ok( seatBookingService.bookSeat(seatDto.getSeatId()));


    }

}
