package flight.system.Flight.booking.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;

import javax.persistence.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Seat {

    @Autowired
    @ManyToOne
    private Flight flight;


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id ;
    private boolean available;
    private String location;



}
