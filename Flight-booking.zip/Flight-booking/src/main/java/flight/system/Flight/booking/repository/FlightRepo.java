package flight.system.Flight.booking.repository;

import flight.system.Flight.booking.entity.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Set;

@Repository
public interface FlightRepo extends JpaRepository<Flight,Long> {
    List<Flight> findByFlightDateBetween(Date start, Date end);
}
