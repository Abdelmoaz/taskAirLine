package flight.system.Flight.booking.repository;



import flight.system.Flight.booking.entity.Flight;
import flight.system.Flight.booking.entity.Seat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface SeatRepo extends JpaRepository<Seat,Long> {
    List<Seat> findByFlightInAndAvailableEquals(List<Flight> flights, Boolean available);
}
