package flight.system.Flight.booking.service;


import flight.system.Flight.booking.entity.Flight;
import flight.system.Flight.booking.repository.FlightRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Set;

@Service
public class FlightService {

    @Autowired
    private FlightRepo flightRepo;

    public List<Flight> getFlights(Date start, Date end){


        return flightRepo.findByFlightDateBetween(start,end);
    }
 public Flight saveFlight(Flight flight){

   return flightRepo.save(flight);

 }

}
