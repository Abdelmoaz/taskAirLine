package flight.system.Flight.booking.service;


import flight.system.Flight.booking.entity.Flight;
import flight.system.Flight.booking.entity.Seat;
import flight.system.Flight.booking.repository.SeatRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public class SeatBookingService {

    @Autowired
    private SeatRepo seatRepo;



    public List<Seat> getAvailableSeats(List<Flight>flights,Boolean available) {

        return seatRepo.findByFlightInAndAvailableEquals(flights,available);
    }

    public Seat saveSeat(Seat seat){

        return seatRepo.save(seat);

    }

    public Seat bookSeat(long id){
        Seat seat = seatRepo.findById(id).get();
        seat.setAvailable(false);
        return seatRepo.save(seat);

    }
}
